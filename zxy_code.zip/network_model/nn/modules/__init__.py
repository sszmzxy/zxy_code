# Ultralytics YOLO 🚀, AGPL-3.0 license
"""
Ultralytics modules.

Example:
    Visualize a module with Netron.
    ```python
    from ultralytics.nn.modules import *
    import torch
    import os

    x = torch.ones(1, 128, 40, 40)
    m = Conv(128, 128)
    f = f'{m._get_name()}.onnx'
    torch.onnx.export(m, x, f)
    os.system(f'onnxsim {f} {f} && open {f}')
    ```
"""

from .block import (
    C1,
    C2,
    C3,
    C3TR,
    DFL,
    SPPF,
    Bottleneck,
    BottleneckCSP,
    C2f,
)
from .conv import (
    ChannelAttention,
    Concat,
    Conv,
    Conv2,
)
from .head import Detect
from .transformer import (
)

__all__ = (
    "Conv",
    "Conv2",
    "ChannelAttention",
    "SPPF",
    "C1",
    "C2",
    "C3",
    "C2f",
    "C3x",
    "C3TR",
    "Bottleneck",
    "BottleneckCSP",
    "Proto",
    "Detect",
)
