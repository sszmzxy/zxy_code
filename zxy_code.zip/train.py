import warnings
warnings.filterwarnings('ignore')
from ultralytics import YOLO

if __name__ == '__main__':
    model = YOLO('ultralytics/cfg/models/v8/yolov8-C2f-RFAConv-AFPN.yaml')

    model.train(data=r'D:/ZXY/zxy_yolo/datasets/myhituav.yaml',
     
                cache=False,
                imgsz=640,
                epochs=300,
                single_cls=False,  # 是否是单类别检测
                batch=16,
                close_mosaic=10,
                workers=4,
                device='0',
                optimizer='SGD', # using SGD
               
                amp=False,  
                project='runs/train',
                name='exp',
                )
