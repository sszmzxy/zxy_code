import warnings
warnings.filterwarnings('ignore')
from ultralytics import YOLO

if __name__ == '__main__':
    model = YOLO('D:/ZXY/zxy_yolo/zxy-val/yolov8x-VisDrone2019/weights/best.pt')
    model.val(data='D:/ZXY/zxy_yolo/datasets/myVisDrone.yaml',
              split='val',
              imgsz=640,
              batch=16,
              # rect=False,
              # save_json=True, # 这个保存coco精度指标的开关
              project='runs/val',
              name='exp',
              )