import warnings
warnings.filterwarnings('ignore')
from ultralytics import YOLO

if __name__ == '__main__':
    model = YOLO('runs/train/zxy/yolov8x_VisDrone2019/weights/best.pt') # select your model.pt path
    model.predict(source='D:/ZXY/zxy_yolo/datasets/VisDrone/VisDrone2019-DET-val/images',
                  imgsz=640,
                  project='runs/detect',
                  name='exp',
                  save=True,
                )