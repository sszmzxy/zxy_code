1.model training
  （1）During the process of model training, directly import the. yaml file of the model to be trained and the corresponding. yaml file of the dataset into train.py in the root directory.
 
---------The specific operation is as follows:
                       model = YOLO('The path where the. yaml file corresponding to the model to be trained is located')

                       model.train(data=r'The path where the. yaml file corresponding to the dataset used for training the model is located',

The relative position of the dataset configuration file in this project is:'datasets/myVisDrone.yaml'


 （2）Some of the main parameters that need to be set before training are also in train.py. If more parameters need to be adjusted, the default.yaml file needs to be opened. The relative address of this file in this folder is' zxy_code/network_model/cfg/default. yaml '

2.The network model proposed in this article has completed its final training on the VisDrone2019 dataset. The relative position of the relevant weight files in the entire folder is' zxy_code/weights', and the relative position of the. yaml file corresponding to the network structure in the folder is' zxy_code/network_model/cfg/models/v8 '
